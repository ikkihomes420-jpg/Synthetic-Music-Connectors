# Synthetic Music Connectors — v1.7.0

Versioned connector packages for Synthetiq Music.

## Gateway v1.7.0 — Smart Search & Real Recommendations

### New in This Release
✅ **Search Pagination** — Now returns 60+ results instead of capped 26  
✅ **Real YouTube Charts** — Actual curated rankings, not fake text-searches  
✅ **Smart Taste Recommendations** — Learns from your listening, blends artist radio  
✅ **Fast Searches** — Parallel continuation loading + aggressive caching  
✅ **Config Fixes** — Unified settings, no more conflicts  

See `CHANGELOG.md` for full details.

## Install

In Synthetiq Music, open **Settings → Sources → Advanced**, then paste:

```
https://github.com/ikkihomes420-jpg/Synthetic-Music-Connectors
```

The app downloads the package named by `catalogue.json`, verifies its SHA-256, and installs it.

## Current Connector

`Synthetiq Music Gateway v1.7.0` — Production-ready with full YouTube Music catalog access, 3-tier fallback streaming (YouTube → Invidious → Piped), and session-local taste learning.

## Publishing Policy

- Keep every released ZIP immutable and versioned
- Add the package SHA-256 to `catalogue.json`
- Retain prior versions for rollback
- Only add provider routes with documented permitted integration
- Never put credentials, audio files, or reusable media URLs in this repo
